import random
import os

print(os.getcwd())

Generation = 1

Loss = 0

BetaRMS = 0.999
BetaMomentum = 0.9

LearningRate = float(input("LearningRate: "))

weights = [0,0,0,0,0,0,0,0,0,0,0,0,0]
bias = [0,0,0,0,0]
Gradients = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

Velocity = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
VelocityLearn = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
VelocityCorrect = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]
VelocityLearnCorrect = [0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0]

inputs = [0,0]
hiddenLayer1 = [0,0,0]
outputs = [0,0]
expectedOutput = [0,0]

# Trainingsdaten laden
training_data = []
with open("training_data.txt", "r") as f:
    for line in f:
        data = list(map(float, line.split()))
        training_data.append(data)

e = 2.718281828459045235360287471352
i = 0
while i < 12:
    weights[i] = random.uniform(-1, 1)
    i = i + 1

i = 0
while i < 5:
    bias[i] = random.uniform(-1, 1)
    i = i + 1



def tanh(x):

    if x > 30: 
        return 1
    if x < -30:
        return -1
    e_x = e**x
    e_mx = e**(-x)
    result = (e_x - e_mx) / (e_x + e_mx) 
    if result != result:  # NaN check
        return 1.0 if x > 0 else -1.0
    return result


def calcGen():
    hiddenLayer1[0] = tanh((inputs[0]*weights[0]+inputs[1]*weights[3])+bias[0])
    hiddenLayer1[1] = tanh((inputs[0]*weights[1]+inputs[1]*weights[4])+bias[1])
    hiddenLayer1[2] = tanh((inputs[0]*weights[2]+inputs[1]*weights[5])+bias[2])

    outputs[0] = tanh((hiddenLayer1[0]*weights[6]+hiddenLayer1[1]*weights[8]+hiddenLayer1[2]*weights[10])+bias[3])
    outputs[1] = tanh((hiddenLayer1[0]*weights[7]+hiddenLayer1[1]*weights[9]+hiddenLayer1[2]*weights[11])+bias[4])

    LossCal = 0.5*(((outputs[0]-expectedOutput[0])**2)+((outputs[1]-expectedOutput[1])**2))
    return LossCal

def Gradientss():
    G2 = (2*(outputs[1]-expectedOutput[1]))*(1-outputs[1]**2)
    G1 = (2*(outputs[0]-expectedOutput[0]))*(1-outputs[0]**2)
    
    Gradients[11] = G2*hiddenLayer1[2]    #Gradienten weights h->o
    Gradients[10] = G1*hiddenLayer1[2]
    Gradients[9] = G2*hiddenLayer1[1]
    Gradients[8] = G1*hiddenLayer1[1]
    Gradients[7] = G2*hiddenLayer1[0]
    Gradients[6] = G1*hiddenLayer1[0]

    Gradients[5] = ((G1*weights[10]+G2*weights[11])*(1-(hiddenLayer1[2]**2)))*inputs[1]    #Gradienten weights i->h
    Gradients[4] = ((G1*weights[10]+G2*weights[11])*(1-(hiddenLayer1[2]**2)))*inputs[0]
    Gradients[3] = ((G1*weights[8]+G2*weights[9])*(1-(hiddenLayer1[1]**2)))*inputs[1]
    Gradients[2] = ((G1*weights[8]+G2*weights[9])*(1-(hiddenLayer1[1]**2)))*inputs[0]
    Gradients[1] = ((G1*weights[6]+G2*weights[7])*(1-(hiddenLayer1[0]**2)))*inputs[1]
    Gradients[0] = ((G1*weights[6]+G2*weights[7])*(1-(hiddenLayer1[0]**2)))*inputs[0]

    Gradients[16] = G2                                                                      #Gradienten bias
    Gradients[15] = G1
    Gradients[14] = (G1*weights[10]+G2*weights[11])*(1-(hiddenLayer1[2]**2))
    Gradients[13] = (G1*weights[8]+G2*weights[9])*(1-(hiddenLayer1[1]**2))
    Gradients[12] = (G1*weights[6]+G2*weights[7])*(1-(hiddenLayer1[0]**2))

def Velocitys():
    for i in range(17):
        Velocity[i] = BetaMomentum*Velocity[i]+(1-BetaMomentum)*Gradients[i]
        VelocityLearn[i] = BetaRMS*VelocityLearn[i]+(1-BetaRMS)*(Gradients[i]**2)
        VelocityCorrect[i] = Velocity[i]/((1-BetaMomentum**Generation)+0.000000000001)
        VelocityLearnCorrect[i] = VelocityLearn[i]/((1-BetaRMS**Generation)+0.000000000000001)

def SetWeightsBias():
    for i in range(12):
        weights[i] = weights[i]-(LearningRate*(VelocityCorrect[i]/((VelocityLearnCorrect[i]**(1/2))+0.00000000000001)))

    for i in range(5):
        bias[i] = bias[i]-(LearningRate*(VelocityCorrect[i+12]/((VelocityLearnCorrect[i+12]**(1/2))+0.00000000000001)))

def training():
    global Generation, Loss
    for epoch in range(30000):
        total_loss = 0
        num_samples = 0
        
        for sample in training_data:
            inputs[0] = sample[0]
            inputs[1] = sample[1]
            expectedOutput[0] = sample[2]
            expectedOutput[1] = sample[3]
            
            Loss = calcGen()  # Forward pass
            total_loss += Loss
            num_samples += 1
            
            Gradientss()      # Gradienten berechnen
            Velocitys()       # Velocity berechnen
            SetWeightsBias()  # Gewichte aktualisieren
            Generation = Generation + 1
        
        avg_loss = total_loss / num_samples
        print(f"Epoch {epoch+1}, Avg Loss: {avg_loss:.8f}")

if input("With TrainingsSets(y/n)") == "y":
    training()
    inputs[0] = float(input("Input 1: "))
    inputs[1] = float(input("Input 2: "))

    Gradientss()
    Velocitys()
    SetWeightsBias()
    Loss = calcGen()
    print("Loss: ", Loss, "Output1: ", outputs[0], "Output2: ", outputs[1])

else:
    inputs[0] = float(input("Input 1: "))
    inputs[1] = float(input("Input 2: "))
    expectedOutput[0] = float(input("Expected Output 1: "))    
    expectedOutput[1] = float(input("Expected Output 2: "))

    calcGen()
    Loss = calcGen()
    while Loss > 0.00000001:
        Gradientss()
        Velocitys()
        SetWeightsBias()
        Generation = Generation + 1
        Loss = calcGen()
        print("Loss: ", Loss, "Output1: ", outputs[0], "Output2: ", outputs[1], "Generation: ", Generation)