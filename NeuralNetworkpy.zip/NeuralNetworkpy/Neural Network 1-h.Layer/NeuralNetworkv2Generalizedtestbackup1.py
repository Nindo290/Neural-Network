import random
import os

print(os.getcwd())

ContentOfLayers = [5,7,5]      #<- HIER GROEßE
biasCount = ContentOfLayers[1]+ContentOfLayers[2]
weightCount = (ContentOfLayers[0]*ContentOfLayers[1]+ContentOfLayers[1]*ContentOfLayers[2])


Generation = 1

Loss = 0

BetaRMS = 0.999
BetaMomentum = 0.9

LearningRate = float(input("LearningRate: "))

weights = [0]*weightCount
bias = [0]*biasCount
Gradients = [0]*(weightCount+biasCount)
Velocity = [0]*(weightCount+biasCount)
VelocityLearn = [0]*(weightCount+biasCount)
VelocityCorrect = [0]*(weightCount+biasCount)
VelocityLearnCorrect = [0]*(weightCount+biasCount)
inputs = [0]*ContentOfLayers[0]
hiddenLayer1 = [0]*ContentOfLayers[1]
outputs = [0]*ContentOfLayers[2]
expectedOutput = [0]*ContentOfLayers[2]
Softmax = input("SoftMax?(1/0)")

ih = len(inputs)*len(hiddenLayer1)
ho = len(hiddenLayer1)*len(outputs)

print(weightCount)
print(len(bias))

# Trainingsdaten laden
training_data = []
with open("training_data.txt", "r") as f:
    for line in f:
        data = list(map(float, line.split()))
        training_data.append(data)

e = 2.718281828459045235360287471352
epsilon = 0.00000000000001
i = 0

while i < weightCount:
    weights[i] = random.uniform(-1, 1)
    i = i + 1

i = 0
while i < biasCount:
    bias[i] = random.uniform(-1, 1)
    i = i + 1

def Save():
    print("DEBUG: Save() wird aufgerufen")
    print(f"DEBUG: weights = {weights}")
    print(f"DEBUG: bias = {bias}")
    print(f"DEBUG: ContentOfLayers = {ContentOfLayers}")
    
    with open("Save.txt", "w", encoding="utf-8") as f:
        line = " ".join(map(str, ContentOfLayers)) + " | "
        line += " ".join(map(str, weights)) + " | "
        line += " ".join(map(str, bias))
        
        print(f"DEBUG: Schreibe diese Zeile:\n{line[:100]}...")  # Erste 100 Zeichen
        f.write(line)
    
    print("DEBUG: Datei geschrieben")

def SoftMax():
    for i in range(len(outputs)):
        outputs[i] = e ^ outputs[i] / sum(e ^ outputs[i])

def tanh(x):

    if x > 30: 
        return 1
    if x < -30:
        return -1
    e_x = e**x
    e_mx = e**(-x)
    result = (e_x - e_mx) / (e_x + e_mx) 
    if result != result:  # NaN check
        return 1.0 if x > 0 else -1.0
    return result

def inputxweight(input, weight):
    y = inputs[input]*weights[weight]
    return y

def hiddenxweight(hidden, weight):
    y = hiddenLayer1[hidden]*weights[weight]
    return y

def hiddencalc(j): 
    cache = 0
    for i in range(ContentOfLayers[0]):
        cache = cache + inputxweight(i, j + i*ContentOfLayers[1])
    return cache

def outputcalc(j): 
    cache = 0
    for i in range(ContentOfLayers[1]):
        cache = cache + hiddenxweight(i, ContentOfLayers[0]*ContentOfLayers[1]+j+i*ContentOfLayers[2])   #<- fertig machen
    return cache

def calcGen():
    for j in range(ContentOfLayers[1]):                       #hiddenLayer1[0] = tanh((inputxweight(0,0)+inputxweight(1,3))+bias[0])
        hiddenLayer1[j] = tanh(hiddencalc(j)+bias[j])    #hiddenLayer1[1] = tanh((inputxweight(0,1)+inputxweight(1,4))+bias[1])
                                                              #hiddenLayer1[2] = tanh((inputxweight(0,2)+inputxweight(1,5))+bias[2])
    for j in range(ContentOfLayers[2]):                              #outputs[0] = tanh((hiddenxweight(0,6)+hiddenxweight(1,8)+hiddenxweight(2,10))+bias[3])
        outputs[j] = tanh(outputcalc(j)+bias[ContentOfLayers[1]+j])   #outputs[1] = tanh((hiddenxweight(0,7)+hiddenxweight(1,9)+hiddenxweight(2,11))+bias[4])

    LossCal = 0.5*(((outputs[0]-expectedOutput[0])**2)+((outputs[1]-expectedOutput[1])**2))
    return LossCal

Fehler = [0]*len(outputs)

def Gradientss():
    for i in range(len(outputs)):
        Fehler[i] = (2*(outputs[i]-expectedOutput[i]))*(1-outputs[i]**2)
    
    activation = (1-(hiddenLayer1[2]**2))

    k = 0
    i2 = 0

    for i in range(ih):
        h = i // len(inputs)        #i->h
        inp = i % len(inputs)           
        Gradients[i] = ((Fehler[0]*weights[ih+2*h] + Fehler[1]*weights[ih+2*h+1]) * (1-(hiddenLayer1[h]**2))) * inputs[inp]
    
    for i in range(ho):             #h->o      
        h = i // ContentOfLayers[2]
        o = i % ContentOfLayers[2]
        Gradients[ih+i] = Fehler[o]*hiddenLayer1[h]

    for i in range(ContentOfLayers[1]):         #hiddenBias
        Gradients[i+weightCount] = (Fehler[0]*weights[ih+2*i] + Fehler[1]*weights[ih+2*i+1])*(1-(hiddenLayer1[i]**2))
           
    for i in range(ContentOfLayers[2]):         #output bias
        Gradients[weightCount+ContentOfLayers[1]] = Fehler[i]

def Velocitys():
    for i in range(weightCount+biasCount):
        Velocity[i] = BetaMomentum*Velocity[i]+(1-BetaMomentum)*Gradients[i]
        VelocityLearn[i] = BetaRMS*VelocityLearn[i]+(1-BetaRMS)*(Gradients[i]**2)
        VelocityCorrect[i] = Velocity[i]/((1-BetaMomentum**Generation)+epsilon)
        VelocityLearnCorrect[i] = VelocityLearn[i]/((1-BetaRMS**Generation)+epsilon)

def SetWeightsBias():
    for i in range(weightCount):
        weights[i] = weights[i]-(LearningRate*(VelocityCorrect[i]/((VelocityLearnCorrect[i]**(1/2))+epsilon)))

    for i in range(biasCount):
        bias[i] = bias[i]-(LearningRate*(VelocityCorrect[i+weightCount]/((VelocityLearnCorrect[i+weightCount]**(1/2))+epsilon)))

def training():
    global Generation, Loss
    for epoch in range(15000):
        total_loss = 0
        num_samples = 0
        
        for sample in training_data:
            inputs[0] = sample[0]
            inputs[1] = sample[1]
            expectedOutput[0] = sample[2]
            expectedOutput[1] = sample[3]
            
            Loss = calcGen()  # Forward pass
            total_loss += Loss
            num_samples += 1
            
            Gradientss()      # Gradienten berechnen
            Velocitys()       # Velocity berechnen
            SetWeightsBias()  # Gewichte aktualisieren
            Generation = Generation + 1
        
        avg_loss = total_loss / num_samples
        print(f"Epoch {epoch+1}, Avg Loss: {avg_loss:.8f}")

if input("With TrainingsSets(y/n)") == "y":
    training()
    inputs[0] = float(input("Input 1: "))
    inputs[1] = float(input("Input 2: "))

    Gradientss()
    Velocitys()
    SetWeightsBias()
    Loss = calcGen()
    print("Loss: ", Loss, "Output1: ", outputs[0], "Output2: ", outputs[1])
    if Softmax == 1:               #IN LOOP ODER NICHT?
        SoftMax()
else:
    for i in range(ContentOfLayers[0]):
        inputs[i] = float(input("Input: "))
        
    for i in range(ContentOfLayers[0]):
        expectedOutput[i] = float(input("Expected Output: "))

    calcGen()
    Loss = calcGen()
    while Loss > 0.00000001:
        Gradientss()
        Velocitys()
        SetWeightsBias()
        Generation = Generation + 1
        Loss = calcGen()
        print("Loss: ", Loss, "Output1: ", outputs[0], "Output2: ", outputs[1], "...", "Generation: ", Generation)
        if Softmax == 1:     #IN LOOP ODER NICHT?
            SoftMax()
if input("Save?(y/n)").strip().lower() == "y":
    Save()
