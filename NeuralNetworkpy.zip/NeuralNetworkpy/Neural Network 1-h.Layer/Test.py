ContentOfLayers = [2,3,2]
biasCount = 5
weightCount = (ContentOfLayers[0]*ContentOfLayers[1]+ContentOfLayers[1]*ContentOfLayers[2])


Generation = 1

Loss = 0

BetaRMS = 0.999
BetaMomentum = 0.9

LearningRate = float(input("LearningRate: "))

weights = [0]*weightCount
bias = [0]*biasCount
Gradients = [0]*(weightCount+biasCount)
Velocity = [0]*(weightCount+biasCount)
VelocityLearn = [0]*(weightCount+biasCount)
VelocityCorrect = [0]*(weightCount+biasCount)
VelocityLearnCorrect = [0]*(weightCount+biasCount)
inputs = [0]*ContentOfLayers[0]
hiddenLayer1 = [0]*ContentOfLayers[1]
outputs = [0]*ContentOfLayers[2]
expectedOutput = [0]*ContentOfLayers[2]

ih = len(inputs)*len(hiddenLayer1)
ho = len(hiddenLayer1)*len(outputs)

Fehler = [0]*len(outputs)

k = 0
i2 = 0


for i in range(weightCount+biasCount):          #gehe durch alle Gradienten
    if i < ih:                                  #i->h
        for _ in range(len(hiddenLayer1)):           #gehe durch hiddenLayer
            for j in range(len(inputs)):        #gehe durch inputs
                Gradients[i] = ((Fehler[0]*weights[ih-1+k-1]+Fehler[1]*weights[ih-1+k+1-1])*(1-(hiddenLayer1[i2]**2)))*inputs[j]
                print(Gradients[i])
            k = k + 2 
            i2 = i2 +1  