import random

layers = int(input("Number of layers: "))

ContentOfLayers = []
weightCount = 0
biasCount = 0

weights=[]
ContentOfLayers = []
for i in range(layers):
    ContentOfLayers.append(int(input(f"Layer {i}: ")))

for i in range(layers - 1):
    weightCount += ContentOfLayers[i] * ContentOfLayers[i+1]

for i in range(1, layers):
    biasCount += ContentOfLayers[i]

Generation = 1

Loss = 0

BetaRMS = 0.999
BetaMomentum = 0.9

#LearningRate = float(input("LearningRate: "))

for i in range(len(ContentOfLayers)-1):
    layerweights= []
    
    for n in range(ContentOfLayers[i+1]):
        neuronweights = [random.random() for _ in range(ContentOfLayers[i])]
        
        layerweights.append(neuronweights)
        
    weights.append(layerweights)
        
    
print("weights: ", weights)
bias = [[0] * ContentOfLayers[i] for i in range(layers)]
Gradients = [0]*(weightCount+biasCount)
Velocity = [0]*(weightCount+biasCount)
VelocityLearn = [0]*(weightCount+biasCount)
VelocityCorrect = [0]*(weightCount+biasCount)
VelocityLearnCorrect = [0]*(weightCount+biasCount)
Values = [[0] * ContentOfLayers[i] for i in range(layers)]
unactivatedValues = [[0] * ContentOfLayers[i] for i in range(layers)]
expectedOutput = [0]*ContentOfLayers[-1]
deltas=[]
for lay in range(1, layers):
    deltas.append([0]*ContentOfLayers[lay])

print("weightCount: ", weightCount)
print("biasCount: ", len(bias))


for i in range(len(Values[0])):
    Values[0][i] = random.random()

print("inputs:", Values[0])

e = 2.718281828459045235360287471352

def tanh(x):
    e_x = e**x
    e_mx = e**(-x)
    return (e_x - e_mx) / (e_x + e_mx)

def ForwardPass():
    lokal = layers
    for lay in range(1, lokal):    #layer
        for i in range(ContentOfLayers[lay]):      #neuron im endlayer
            total = 0
            for j in range(ContentOfLayers[lay-1]):      #neuronrn im startlayer
                total += Values[lay-1][j]*weights[lay-1][i][j]
            total = total + bias[lay][i]
            unactivatedValues[lay][i] = total    
            total = tanh(total)
            Values[lay][i] = total
ForwardPass()

def LossCalc():
    total = 0
    for i in range(ContentOfLayers[-1]):
        total += (Values[-1][i]-expectedOutput[i])**2
    total = 0.5*total

def Backpropagation():
    



def SetWeights():

        
